# -*- coding: utf-8 -*-
'''
    SaltStack Enterprise API Client
'''

from sseapiclient._version import get_versions
__version__ = get_versions()['version']
del get_versions

from sseapiclient.apiclient import APIClient, RPCResponse
