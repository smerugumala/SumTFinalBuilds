# coding: utf-8
'''
The SSE Event Queue engine

Periodically get events from the local event queue and send them to raas
'''

# Copyright (C) 2020 SaltStack, Inc.
#
# This file is licensed only for use with SaltStack's Enterprise software
# product and may not be used for any other purpose without prior written
# authorization from SaltStack, Inc.  The license terms governing your use of
# Salt Stack Enterprise also govern your use of this file. See license terms at
# https://www.saltstack.com/terms/

# Import Python libs
from __future__ import absolute_import
import logging
import os

# Import Salt libs
import salt.config
import salt.loader
import salt.syspaths

# Import SSEAPE libs
import sseape.utils.config as sseape_config
from sseape.utils.engine import QueueEngineBase

__virtualname__ = 'eventqueue'
log = logging.getLogger(__name__)


def __virtual__():
    if '__role' not in __opts__:
        return False, 'Unable to find out the role(master or minion)'
    if __opts__['__role'] != 'master':
        return (False,
                'The SSE Event Queue engine is meant to run on the salt-master, '
                'not on {0}'.format(__opts__['__role']))
    if 'sseapi_event_queue' in __opts__ and __opts__['sseapi_event_queue'].get('strategy') in ('always', 'on_failure'):
        return True
    else:
        return False, 'SSE Event queue not enabled.'


class EventQueueEngine(QueueEngineBase):

    def __init__(self, opts=None, raas_client=None):

        super(EventQueueEngine, self).__init__(config_name='sseapi_event_queue',
                                               opts=opts,
                                               raas_client=raas_client)

        self.master_id = self.opts.get('sseapi_cluster_id') or self.opts['id']
        self.returners = salt.loader.returners(self.opts, __salt__)

        self.forward = sseape_config.get(self.opts, 'sseapi_event_queue.forward')
        if not self.forward:
            self.forward = []
        elif not isinstance(self.forward, list):
            self.forward = [self.forward]

    def send_entries(self, entries):
        '''
        Send events to raas. Base class handles exceptions.
        '''
        events = [item['data'] for item in entries]
        self.raas_client.api.ret.save_event(self.master_id, events)

        for ret in self.forward:
            event_return = '{}.event_return'.format(ret)
            if event_return in self.returners:
                try:
                    log.info('Forwarding %d events to %s', len(events), event_return)
                    self.returners[event_return](events)
                except Exception as exc:  # pylint: disable=broad-except
                    log.error('Could not forward events: %s raised an exception: %s',
                            event_return, exc)
            else:
                log.error('Could not forward events: %s not found', event_return)


def start(raas_client=None):
    '''
    Start the engine
    '''
    opts = globals().get('__opts__')
    if opts is None:
        opts = salt.config.master_config(os.path.join(salt.syspaths.CONFIG_DIR, 'master'))

    EventQueueEngine(opts, raas_client).start()
