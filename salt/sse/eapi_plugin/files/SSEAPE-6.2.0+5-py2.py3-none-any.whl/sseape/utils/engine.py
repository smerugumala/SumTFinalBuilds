# coding: utf-8
'''
RaaS engine utils
'''

# Copyright (C) 2020 SaltStack, Inc.
#
# This file is licensed only for use with SaltStack's Enterprise software
# product and may not be used for any other purpose without prior written
# authorization from SaltStack, Inc.  The license terms governing your use of
# Salt Stack Enterprise also govern your use of this file. See license terms at
# https://www.saltstack.com/terms/

# Import Python libs
from __future__ import absolute_import
import logging
import time

# Import 3rd-party libs
from sseapiclient.exc import NotConnectable, RequestFailure

# Import Salt libs
import salt.loader
from salt.exceptions import CommandExecutionError

# Import SSEAPE libs
import sseape.utils.config as sseape_config
from sseape.utils.client import make_api_client

__salt__ = None

log = logging.getLogger(__name__)


class QueueEngineBase(object):
    '''
    Base class for engines that queue things and send them to raas periodically
    '''

    def __init__(self, config_name, opts=None, raas_client=None):
        global __salt__
        if __salt__ is None:
            __salt__ = salt.loader.minion_mods(opts)

        self.config_name = config_name
        self.opts = opts
        self.raas_client = raas_client
        self.last_vacuum = 0.0

        def get_config(name):
            return sseape_config.get(self.opts, '{}.{}'.format(self.config_name, name))

        self.name = get_config('name')
        self.strategy = get_config('strategy')
        self.push_interval = get_config('push_interval')
        self.batch_limit = get_config('batch_limit')
        self.age_limit = get_config('age_limit')
        self.size_limit = get_config('size_limit')
        self.vacuum_interval = get_config('vacuum_interval')
        self.vacuum_limit = get_config('vacuum_limit')

    def _purge_entries(self):
        '''
        Purge old entries from the queue to enforce age and size limits
        '''
        try:
            purged = __salt__['sseapi_local_queue.purge'](queue=self.name, age_limit=self.age_limit)
            if purged > 0:
                log.warning('queue %s: discarded %d items due to age limit', self.name, purged)
            purged = __salt__['sseapi_local_queue.purge'](queue=self.name, size_limit=self.size_limit)
            if purged > 0:
                log.warning('queue %s: discarded %d items due to size limit', self.name, purged)
        except CommandExecutionError as exc:
            log.error('%s: failed to purge old entries from queue: %s', self.config_name, str(exc))

    def _pop_entries(self):
        '''
        Pop entries from the queue for sending to raas
        '''
        try:
            return __salt__['sseapi_local_queue.pop'](queue=self.name, limit=self.batch_limit)
        except CommandExecutionError as exc:
            log.error('%s: failed to pop entries from queue: %s', self.config_name, str(exc))

    def _push_entries(self, entries):
        '''
        Push entries back onto the queue, presumably because the send failed
        '''
        try:
            __salt__['sseapi_local_queue.push'](queue=self.name, items=entries)
        except CommandExecutionError as exc:
            log.error('%s: failed to push entries onto queue: %s', self.config_name, str(exc))

    def _process_entries(self):
        '''
        Pop entries from the queue and send them to raas
        '''
        entries = None
        try:
            self._purge_entries()
            entries = self._pop_entries()
            if entries:
                log.info('%s: retrieved %d entries from local queue', self.config_name, len(entries))
                self.send_entries(entries)
            else:
                log.info('%s: no entries to send to SSE', self.config_name)
        except Exception as exc:  # pylint: disable=broad-except
            log.error('%s: failed to send entries to SSE: %s', self.config_name, str(exc))
            if entries:
                self._push_entries(entries)

    def _vacuum_if_due(self):
        '''
        Try to vacuum the queue database if it's time
        '''
        now = time.time()
        if now > self.last_vacuum + self.vacuum_interval:
            try:
                if __salt__['sseapi_local_queue.vacuum'](queue=self.name, max_entries=self.vacuum_limit):
                    self.last_vacuum = now
            except CommandExecutionError as exc:
                log.error('%s: failed to vacuum queue database: %s', self.config_name, str(exc))

    def send_entries(self, entries):
        '''
        Derived class implementations should send queue entries to raas and
        raise an exception on failure. A failure will cause entries to be
        re-queued.
        '''
        raise NotImplementedError

    def start(self):
        while True:
            log.info('Start %s engine iteration...', self.config_name)

            if not __salt__['sseapi_local_queue.queue_exists'](queue=self.name):
                log.info('%s: queue does not exist, skipping this iteration', self.config_name)
                time.sleep(self.push_interval)
                continue

            if self.raas_client is None:
                try:
                    self.raas_client = make_api_client(self.opts)
                except (NotConnectable, RequestFailure) as exc:
                    log.error('%s: could not connect to SSE server: %s', self.config_name, str(exc))
                    time.sleep(self.push_interval)
                    continue

            start = time.time()
            try:
                self._process_entries()
                self._vacuum_if_due()
            except Exception as exc:  # pylint: disable=broad-except
                log.info('%s: engine iteration interrupted with exception: %s',
                        self.config_name, exc, exc_info=True)
            duration = time.time() - start

            # If the iteration ran longer than the interval, sleep a little anyway
            stime = self.push_interval - duration
            if stime < 0:
                log.warning('%s: engine iteration time (%.1fs) exceeded push interval (%.1fs)',
                        self.config_name, duration, self.push_interval)
                stime = min(5, self.push_interval / 5)

            # Sleep before the next iteration.
            log.info('%s: engine sleeping for %.1f seconds', self.config_name, stime)
            time.sleep(stime)
